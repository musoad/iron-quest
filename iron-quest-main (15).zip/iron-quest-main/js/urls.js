// js/urls.js
window.URLS = (function(){
  // Optional: Trage hier eine Backup-URL ein (eigener Server/Webhook).
  // Die App sendet dann JSON Backups per POST.
  // Beispiel: https://dein-server.de/ironquest-backup
  const DEFAULT_BACKUP_ENDPOINT = "";

  return {
    DEFAULT_BACKUP_ENDPOINT
  };
})();
